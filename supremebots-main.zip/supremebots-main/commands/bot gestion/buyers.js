const Discord = require('discord.js');
const {bot} = require('../../structures/client'); 
const request = require('request');
const fs = require('fs');

module.exports = {
    name: "buyers",
    aliases: [],
    description: "Permet de lister les buyers",
    category: "proprio",
    usage: ["buyers"],

    /**
     * @param {bot} client  
     * @param {Discord.Message} message 
     * @param {Array<>} args 
     * @param {string} commandName 
     */

    run: async (client, message, args, color, prefix, footer, commandName) => {

        //A RE FAIRE

    }}
