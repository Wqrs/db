discord : sonnyyyyyyyyy, lqhv, 1tsubasa and not.seven 

Ancienne version du gestion de supremebots (en cours de correction).
